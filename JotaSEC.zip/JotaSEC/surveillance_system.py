import cv2
import pyautogui
import numpy as np
import os
import time
from datetime import datetime
import threading
import logging
import json

# Configuración
CONFIG = {
    'min_contour_area': 1000,
    'motion_threshold': 25,
    'min_detection_frames': 5,  # Reducido para respuesta más rápida
    'cooldown_frames': 20,
    'check_interval': 0.1,
    'output_folder': 'vigilancia_records',
    'video_fps': 20,
    'resolution': (640, 480),
    'learning_rate': 0.01,
    'motion_log_file': 'motion_events.json'
}

class RoomSurveillanceSystem:
    def __init__(self, config):
        self.config = config
        self.is_recording = False
        self.motion_counter = 0
        self.cooldown_counter = 0
        self.video_writer_webcam = None
        self.video_writer_screen = None
        self.background = None
        self.current_session = None
        self.motion_events = []
        self.setup_logging()
        self.setup_directories()
        
    def setup_logging(self):
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('surveillance.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
    
    def setup_directories(self):
        if not os.path.exists(self.config['output_folder']):
            os.makedirs(self.config['output_folder'])
    
    def initialize_webcam(self):
        """Inicializa la webcam"""
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            self.logger.error("No se pudo acceder a la webcam")
            return False
        
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.config['resolution'][0])
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.config['resolution'][1])
        
        self.logger.info("Inicializando fondo, mantente fuera del campo de visión...")
        time.sleep(2)
        
        frames = []
        for i in range(30):
            ret, frame = self.cap.read()
            if ret:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                gray = cv2.GaussianBlur(gray, (21, 21), 0)
                frames.append(gray)
            time.sleep(0.1)
        
        if frames:
            self.background = np.median(frames, axis=0).astype(np.float32)
            self.logger.info("Webcam inicializada correctamente")
            return True
        return False
    
    def log_motion_event(self, event_type, timestamp=None, details=None):
        """Registra eventos de movimiento en el log y archivo JSON"""
        if timestamp is None:
            timestamp = datetime.now()
        
        event = {
            'timestamp': timestamp.isoformat(),
            'event_type': event_type,
            'session': self.current_session,
            'details': details or {}
        }
        
        self.motion_events.append(event)
        
        # Log en archivo de texto
        self.logger.info(f"MOVIMIENTO - {event_type} - Sesión: {self.current_session}")
        
        # Guardar en archivo JSON para fácil acceso
        self.save_motion_events()
        
        return event
    
    def save_motion_events(self):
        """Guarda los eventos de movimiento en archivo JSON"""
        try:
            with open(self.config['motion_log_file'], 'w', encoding='utf-8') as f:
                json.dump(self.motion_events, f, indent=2, ensure_ascii=False)
        except Exception as e:
            self.logger.error(f"Error guardando eventos de movimiento: {e}")
    
    def detect_motion(self, frame):
        """Detecta movimiento en el frame y retorna información detallada"""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (21, 21), 0)
        gray_float = gray.astype(np.float32)
        
        # Calcular diferencia con el fondo
        frame_delta = cv2.absdiff(self.background.astype(np.uint8), gray)
        thresh = cv2.threshold(frame_delta, self.config['motion_threshold'], 255, cv2.THRESH_BINARY)[1]
        thresh = cv2.dilate(thresh, None, iterations=2)
        
        # Encontrar contornos y calcular área total de movimiento
        contours, _ = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        motion_detected = False
        total_motion_area = 0
        motion_regions = []
        
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > self.config['min_contour_area']:
                motion_detected = True
                total_motion_area += area
                # Obtener bounding box del movimiento
                x, y, w, h = cv2.boundingRect(contour)
                motion_regions.append({'x': x, 'y': y, 'w': w, 'h': h, 'area': area})
        
        # Actualizar fondo gradualmente (solo si no hay movimiento significativo)
        if not motion_detected or total_motion_area < 5000:
            cv2.accumulateWeighted(gray_float, self.background, self.config['learning_rate'])
        
        return motion_detected, total_motion_area, motion_regions
    
    def start_recording(self):
        """Inicia la grabación de webcam y pantalla"""
        timestamp = datetime.now()
        self.current_session = timestamp.strftime("%Y%m%d_%H%M%S")
        
        # Configurar codec y writers
        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        
        # Webcam writer
        webcam_filename = os.path.join(
            self.config['output_folder'], 
            f"webcam_{self.current_session}.avi"
        )
        self.video_writer_webcam = cv2.VideoWriter(
            webcam_filename, fourcc, self.config['video_fps'], 
            self.config['resolution']
        )
        
        # Screen writer
        screen_filename = os.path.join(
            self.config['output_folder'], 
            f"pantalla_{self.current_session}.avi"
        )
        screen_size = pyautogui.size()
        self.video_writer_screen = cv2.VideoWriter(
            screen_filename, fourcc, self.config['video_fps'], 
            screen_size
        )
        
        self.is_recording = True
        
        # Registrar inicio de sesión
        self.log_motion_event(
            'SESSION_START', 
            timestamp,
            {
                'webcam_file': f"webcam_{self.current_session}.avi",
                'screen_file': f"pantalla_{self.current_session}.avi",
                'resolution': self.config['resolution']
            }
        )
        
        self.logger.info(f"Iniciando grabación: {self.current_session}")
    
    def stop_recording(self):
        """Detiene la grabación"""
        if self.video_writer_webcam:
            self.video_writer_webcam.release()
        if self.video_writer_screen:
            self.video_writer_screen.release()
        
        # Registrar fin de sesión
        if self.current_session:
            self.log_motion_event('SESSION_END')
        
        self.is_recording = False
        self.current_session = None
        self.logger.info("Grabación detenida")
    
    def record_screen(self):
        """Grabación de pantalla en hilo separado"""
        while self.is_recording:
            try:
                screenshot = pyautogui.screenshot()
                frame = np.array(screenshot)
                frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
                self.video_writer_screen.write(frame)
                time.sleep(1/self.config['video_fps'])
            except Exception as e:
                self.logger.error(f"Error grabando pantalla: {e}")
                break
    
    def run(self):
        """Ejecuta el sistema principal"""
        if not self.initialize_webcam():
            return
        
        self.logger.info("Sistema de vigilancia iniciado")
        screen_thread = None
        last_motion_time = None
        
        try:
            while True:
                ret, frame = self.cap.read()
                if not ret:
                    self.logger.error("Error leyendo frame de webcam")
                    break
                
                frame = cv2.resize(frame, self.config['resolution'])
                current_time = datetime.now()
                
                # Detectar movimiento con información detallada
                motion_detected, motion_area, motion_regions = self.detect_motion(frame)
                
                if self.cooldown_counter > 0:
                    self.cooldown_counter -= 1
                
                if motion_detected and self.cooldown_counter == 0:
                    self.motion_counter += 1
                    
                    # Registrar movimiento significativo
                    if self.motion_counter >= 2:  # Evitar falsos positivos iniciales
                        if last_motion_time is None or (current_time - last_motion_time).total_seconds() > 5:
                            self.log_motion_event(
                                'MOTION_DETECTED',
                                current_time,
                                {
                                    'motion_area': motion_area,
                                    'regions_count': len(motion_regions),
                                    'regions': motion_regions[:3]  # Máximo 3 regiones
                                }
                            )
                            last_motion_time = current_time
                    
                    # Iniciar grabación si hay suficiente movimiento
                    if not self.is_recording and self.motion_counter >= self.config['min_detection_frames']:
                        self.start_recording()
                        screen_thread = threading.Thread(target=self.record_screen)
                        screen_thread.daemon = True
                        screen_thread.start()
                
                else:
                    # Si no hay movimiento y estábamos grabando, detener
                    if self.is_recording and self.motion_counter > 0:
                        self.motion_counter -= 1
                        if self.motion_counter == 0:
                            self.stop_recording()
                            self.cooldown_counter = self.config['cooldown_frames']
                            if screen_thread and screen_thread.is_alive():
                                screen_thread.join(timeout=2.0)
                
                # Si estamos grabando, guardar frame de webcam
                if self.is_recording:
                    self.video_writer_webcam.write(frame)
                
                # Mostrar información de movimiento en pantalla
                status_text = f"Estado: {'GRABANDO' if self.is_recording else 'MONITOREANDO'}"
                cv2.putText(frame, status_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, 
                           (0, 0, 255) if self.is_recording else (0, 255, 0), 2)
                
                if motion_detected:
                    motion_text = f"Movimiento: {motion_area:.0f} px"
                    cv2.putText(frame, motion_text, (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6, 
                               (0, 0, 255), 2)
                    
                    # Dibujar rectángulos en áreas de movimiento
                    for region in motion_regions:
                        x, y, w, h = region['x'], region['y'], region['w'], region['h']
                        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
                
                cv2.imshow('Vigilancia - Presiona Q para salir', frame)
                
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                
                time.sleep(self.config['check_interval'])
        
        except KeyboardInterrupt:
            self.logger.info("Sistema interrumpido por el usuario")
        except Exception as e:
            self.logger.error(f"Error en el sistema: {e}")
        finally:
            if self.is_recording:
                self.stop_recording()
            self.cap.release()
            cv2.destroyAllWindows()
            self.save_motion_events()
            self.logger.info("Sistema de vigilancia detenido")

# Script para revisar los eventos grabados
class MotionEventReviewer:
    def __init__(self, log_file='motion_events.json'):
        self.log_file = log_file
        self.events = self.load_events()
    
    def load_events(self):
        """Carga los eventos desde el archivo JSON"""
        try:
            with open(self.log_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            print("No se encontró el archivo de eventos")
            return []
        except Exception as e:
            print(f"Error cargando eventos: {e}")
            return []
    
    def list_sessions(self):
        """Lista todas las sesiones de grabación"""
        sessions = {}
        for event in self.events:
            if event['event_type'] == 'SESSION_START':
                session_id = event['session']
                sessions[session_id] = {
                    'start_time': event['timestamp'],
                    'webcam_file': event['details']['webcam_file'],
                    'screen_file': event['details']['screen_file']
                }
        
        print("\n=== SESIONES GRABADAS ===")
        for i, (session_id, info) in enumerate(sessions.items(), 1):
            print(f"{i}. Sesión: {session_id}")
            print(f"   Inicio: {info['start_time']}")
            print(f"   Archivos: {info['webcam_file']}, {info['screen_file']}")
            print()
        
        return sessions
    
    def show_motion_timeline(self, session_id):
        """Muestra la línea de tiempo de movimiento para una sesión"""
        print(f"\n=== MOVIMIENTOS EN SESIÓN {session_id} ===")
        
        motion_events = []
        session_start = None
        
        for event in self.events:
            if event['session'] == session_id:
                if event['event_type'] == 'SESSION_START':
                    session_start = datetime.fromisoformat(event['timestamp'])
                elif event['event_type'] == 'MOTION_DETECTED':
                    motion_time = datetime.fromisoformat(event['timestamp'])
                    if session_start:
                        time_offset = (motion_time - session_start).total_seconds()
                        motion_events.append({
                            'time_offset': time_offset,
                            'details': event['details']
                        })
        
        for i, motion in enumerate(motion_events, 1):
            minutes = int(motion['time_offset'] // 60)
            seconds = int(motion['time_offset'] % 60)
            area = motion['details']['motion_area']
            regions = motion['details']['regions_count']
            
            print(f"{i}. Tiempo: {minutes:02d}:{seconds:02d} - Área: {area:.0f} px - Regiones: {regions}")
    
    def play_video_from_time(self, video_file, start_seconds):
        """Reproduce un video desde un tiempo específico"""
        cap = cv2.VideoCapture(video_file)
        if not cap.isOpened():
            print(f"No se pudo abrir el video: {video_file}")
            return
        
        # Saltar al tiempo específico
        fps = cap.get(cv2.CAP_PROP_FPS)
        target_frame = int(start_seconds * fps)
        cap.set(cv2.CAP_PROP_POS_FRAMES, target_frame)
        
        print(f"Reproduciendo desde {start_seconds} segundos...")
        
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            # Mostrar tiempo actual
            current_frame = cap.get(cv2.CAP_PROP_POS_FRAMES)
            current_time = current_frame / fps
            
            cv2.putText(frame, f"Tiempo: {current_time:.1f}s", (10, 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
            
            cv2.imshow(f'Revisión: {os.path.basename(video_file)}', frame)
            
            if cv2.waitKey(25) & 0xFF == ord('q'):
                break
        
        cap.release()
        cv2.destroyAllWindows()

def review_recordings():
    """Función para revisar las grabaciones"""
    reviewer = MotionEventReviewer()
    
    while True:
        print("\n=== REVISOR DE GRABACIONES ===")
        print("1. Listar sesiones grabadas")
        print("2. Ver línea de tiempo de movimiento")
        print("3. Reproducir video desde tiempo específico")
        print("4. Salir")
        
        choice = input("Selecciona una opción: ").strip()
        
        if choice == '1':
            reviewer.list_sessions()
        
        elif choice == '2':
            session_id = input("Ingresa el ID de sesión (ej: 20231107_143022): ").strip()
            reviewer.show_motion_timeline(session_id)
        
        elif choice == '3':
            video_file = input("Ruta del archivo de video: ").strip()
            try:
                start_time = float(input("Tiempo inicial (segundos): "))
                reviewer.play_video_from_time(video_file, start_time)
            except ValueError:
                print("Tiempo inválido")
        
        elif choice == '4':
            break
        
        else:
            print("Opción inválida")

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == 'review':
        review_recordings()
    else:
        system = RoomSurveillanceSystem(CONFIG)
        system.run()